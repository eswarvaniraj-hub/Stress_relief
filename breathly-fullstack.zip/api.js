// ==========================================================================
// Breathly backend API client (new file — plain <script>, defines window.api)
// Talks to the Express/MySQL backend on http://localhost:5000
// Sessions are cookie-based, so every call uses credentials: 'include'.
// ==========================================================================
(function () {
  const BASE_URL = 'http://localhost:5000/api';

  async function request(path, options = {}) {
    const res = await fetch(BASE_URL + path, {
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      ...options
    });
    let data = null;
    try { data = await res.json(); } catch (e) {}
    if (!res.ok) {
      const message = (data && data.error) || `Request failed (${res.status})`;
      throw new Error(message);
    }
    return data;
  }

  window.api = {
    // Auth
    loginWithGoogle: (credential) =>
      request('/auth/google', { method: 'POST', body: JSON.stringify({ credential }) }),
    me: () => request('/auth/me'),
    logout: () => request('/auth/logout', { method: 'POST' }),

    // Journal
    listJournal: () => request('/journal'),
    createJournalEntry: (content, mood) =>
      request('/journal', { method: 'POST', body: JSON.stringify({ content, mood }) }),
    deleteJournalEntry: (id) => request(`/journal/${id}`, { method: 'DELETE' }),

    // Breathing
    createBreathingSession: (exerciseName, durationSeconds) =>
      request('/breathing/sessions', { method: 'POST', body: JSON.stringify({ exerciseName, durationSeconds }) }),

    // Stress
    createStressRecord: (stressLevel) =>
      request('/stress', { method: 'POST', body: JSON.stringify({ stressLevel }) }),

    // Preferences
    getPreferences: () => request('/preferences'),
    updatePreferences: (theme, notificationEnabled) =>
      request('/preferences', { method: 'PUT', body: JSON.stringify({ theme, notificationEnabled }) })
  };
})();
