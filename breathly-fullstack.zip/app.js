// ==========================================================================
// RESET - Modern Emotional Wellness & Stress Relief Application
// Includes: Google Identity Services (Sign in with Google) Integration
// ==========================================================================

const { useState, useEffect, useRef, useMemo } = React;

// --- STORAGE KEYS ---
const STORAGE_KEY = 'reset_app_state_v1';
const USER_STORAGE_KEY = 'reset_auth_user_v1';
const GOOGLE_CLIENT_ID_KEY = 'reset_google_client_id_v1';

// Default Demo/Preset Google Client ID (Can be replaced with user's own from Google Cloud)
const DEFAULT_GOOGLE_CLIENT_ID = '928374829102-demo.apps.googleusercontent.com';

const DEFAULT_INITIAL_STATE = {
  theme: 'dusk', // 'dusk' | 'sage' | 'midnight' | 'sunrise'
  soundEnabled: true,
  soundVolume: 0.5,
  ambientSound: 'none', // 'none' | 'rain' | 'waves' | 'bowl' | 'forest'
  resetsHistory: [
    {
      id: 'demo-1',
      timestamp: Date.now() - 86400000 * 2,
      feeling: 'Overwhelmed',
      feelingEmoji: '🤯',
      trigger: 'Studies / exams',
      activityId: 'focus-reset',
      activityTitle: '2-Minute Reset & Focus',
      stressBefore: 8,
      stressAfter: 4,
      rating: 'Much better',
      durationSec: 120
    },
    {
      id: 'demo-2',
      timestamp: Date.now() - 86400000 * 1,
      feeling: 'Very stressed',
      feelingEmoji: '😰',
      trigger: 'Work',
      activityId: 'breathing-426',
      activityTitle: '60s Calming Breathing (4-2-6)',
      stressBefore: 9,
      stressAfter: 4,
      rating: 'Much better',
      durationSec: 60
    },
    {
      id: 'demo-3',
      timestamp: Date.now() - 3600000 * 4,
      feeling: 'Overthinking',
      feelingEmoji: '🧠',
      trigger: 'Overthinking',
      activityId: 'breathing-426',
      activityTitle: '60s Calming Breathing (4-2-6)',
      stressBefore: 7,
      stressAfter: 3,
      rating: 'Much better',
      durationSec: 60
    }
  ]
};

// --- HELPER: JWT TOKEN DECODER ---
function parseJwt(token) {
  try {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const jsonPayload = decodeURIComponent(
      atob(base64)
        .split('')
        .map(c => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
        .join('')
    );
    return JSON.parse(jsonPayload);
  } catch (e) {
    console.warn('JWT parse error:', e);
    return null;
  }
}

// --- PROCEDURAL WEB AUDIO SYNTHESIZER ---
class CalmAudioEngine {
  constructor() {
    this.ctx = null;
    this.ambientNode = null;
    this.gainNode = null;
    this.masterGain = null;
    this.currentAmbientType = 'none';
  }

  init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
        this.masterGain = this.ctx.createGain();
        this.masterGain.gain.setValueAtTime(0.5, this.ctx.currentTime);
        this.masterGain.connect(this.ctx.destination);
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  setMasterVolume(val) {
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(Math.max(0, Math.min(1, val)), this.ctx.currentTime, 0.05);
    }
  }

  playChime(type = 'soft') {
    try {
      this.init();
      if (!this.ctx) return;
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      
      const freqs = type === 'inhale' ? [432, 648] : type === 'hold' ? [528] : [384, 576];
      const rootFreq = freqs[0];

      osc.type = 'sine';
      osc.frequency.setValueAtTime(rootFreq, t);

      const osc2 = this.ctx.createOscillator();
      const gain2 = this.ctx.createGain();
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(freqs[1] || rootFreq * 1.5, t);

      gain.gain.setValueAtTime(0.001, t);
      gain.gain.exponentialRampToValueAtTime(0.2, t + 0.15);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 2.5);

      gain2.gain.setValueAtTime(0.001, t);
      gain2.gain.exponentialRampToValueAtTime(0.08, t + 0.1);
      gain2.gain.exponentialRampToValueAtTime(0.0001, t + 2.0);

      osc.connect(gain);
      osc2.connect(gain2);
      gain.connect(this.masterGain);
      gain2.connect(this.masterGain);

      osc.start(t);
      osc2.start(t);
      osc.stop(t + 2.6);
      osc2.stop(t + 2.6);
    } catch (e) {
      console.warn('Audio play error:', e);
    }
  }

  stopAmbient() {
    if (this.ambientNode) {
      try {
        if (this.ambientNode.stop) this.ambientNode.stop();
        if (this.ambientNode.disconnect) this.ambientNode.disconnect();
      } catch (e) {}
      this.ambientNode = null;
    }
    this.currentAmbientType = 'none';
  }

  playAmbient(type) {
    this.init();
    if (!this.ctx) return;
    if (this.currentAmbientType === type) return;
    this.stopAmbient();

    if (type === 'none') return;
    this.currentAmbientType = type;

    const t = this.ctx.currentTime;
    const bufferSize = 2 * this.ctx.sampleRate;
    const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);

    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }

    const whiteNoise = this.ctx.createBufferSource();
    whiteNoise.buffer = noiseBuffer;
    whiteNoise.loop = true;

    if (type === 'rain') {
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(900, t);

      const rainGain = this.ctx.createGain();
      rainGain.gain.setValueAtTime(0.12, t);

      whiteNoise.connect(filter);
      filter.connect(rainGain);
      rainGain.connect(this.masterGain);
      whiteNoise.start();
      this.ambientNode = whiteNoise;
    } else if (type === 'waves') {
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(450, t);
      filter.Q.setValueAtTime(1.5, t);

      const waveGain = this.ctx.createGain();
      waveGain.gain.setValueAtTime(0.08, t);

      const lfo = this.ctx.createOscillator();
      lfo.frequency.setValueAtTime(0.12, t);
      const lfoGain = this.ctx.createGain();
      lfoGain.gain.setValueAtTime(300, t);

      lfo.connect(filter.frequency);
      whiteNoise.connect(filter);
      filter.connect(waveGain);
      waveGain.connect(this.masterGain);

      lfo.start();
      whiteNoise.start();
      this.ambientNode = {
        stop: () => {
          whiteNoise.stop();
          lfo.stop();
        }
      };
    } else if (type === 'bowl' || type === 'forest') {
      const osc1 = this.ctx.createOscillator();
      const osc2 = this.ctx.createOscillator();
      const droneGain = this.ctx.createGain();

      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(216, t);
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(432, t);

      droneGain.gain.setValueAtTime(0.06, t);
      osc1.connect(droneGain);
      osc2.connect(droneGain);
      droneGain.connect(this.masterGain);

      osc1.start();
      osc2.start();
      this.ambientNode = {
        stop: () => {
          osc1.stop();
          osc2.stop();
        }
      };
    }
  }
}

const audioService = new CalmAudioEngine();

// --- PRESET ACTIVITIES DEFINITIONS ---
const ACTIVITIES = {
  'breathing-426': {
    id: 'breathing-426',
    title: '60s Calming Breathing (4-2-6)',
    tag: 'Quick Breath',
    icon: 'wind',
    duration: 60,
    type: 'breathing',
    pattern: { inhale: 4, hold: 2, exhale: 6 },
    description: 'A scientifically validated calming cadence that activates the parasympathetic nervous system and slows heart rate.',
    why: 'Longer exhales signal to your vagus nerve that you are completely safe.'
  },
  'breathing-box': {
    id: 'breathing-box',
    title: 'Box Breathing (4-4-4-4)',
    tag: 'Focus & Calm',
    icon: 'square',
    duration: 64,
    type: 'breathing',
    pattern: { inhale: 4, hold: 4, exhale: 4, holdPost: 4 },
    description: 'Used by first responders and high-stress professionals to regain immediate composure and steady concentration.',
    why: 'Equal breathing intervals steady blood pressure and stop adrenaline spikes.'
  },
  'grounding-54321': {
    id: 'grounding-54321',
    title: 'Pause & 5-4-3-2-1 Sensory Grounding',
    tag: 'Grounding',
    icon: 'anchor',
    duration: 90,
    type: 'grounding',
    description: 'Reconnect with your physical surroundings through five simple sensory anchors to stop spinning thoughts.',
    why: 'Redirects mental processing from emotional alarm centers directly into sensory perception.'
  },
  'focus-reset': {
    id: 'focus-reset',
    title: '2-Minute Reset + Focus Timer',
    tag: 'Clarity',
    icon: 'zap',
    duration: 120,
    type: 'focus',
    description: 'A micro-mental reset with soothing audio and gentle prompts to clear cognitive clutter.',
    why: 'Gives your prefrontal cortex a fresh 120-second reboot before returning to your task.'
  },
  'body-scan': {
    id: 'body-scan',
    title: 'Short Body Un-Clench & Relaxation',
    tag: 'Somatic Release',
    icon: 'smile',
    duration: 75,
    type: 'body-scan',
    description: 'Releases unconscious muscular tension held tightly in your jaw, neck, shoulders, and brow.',
    why: 'Physical relaxation directly commands your mind to drop high-alert mode.'
  },
  'thought-bubbles': {
    id: 'thought-bubbles',
    title: 'Worry Bubble De-Clutter',
    tag: 'Mind Cleanse',
    icon: 'sparkles',
    duration: 60,
    type: 'bubbles',
    description: 'Visualize stressful worries as gentle bubbles and pop them to let them dissolve peacefully into stardust.',
    why: 'Creates cognitive distance (defusion) between you and overwhelming thoughts.'
  }
};

// --- SMART RECOMMENDATION ENGINE ---
function getSmartRecommendation(feeling, trigger, history) {
  const stats = calculateActivityStats(history);
  
  if (trigger === 'Studies / exams') {
    return ACTIVITIES['focus-reset'];
  }
  if (feeling === 'Angry' || trigger === 'Anger') {
    return ACTIVITIES['grounding-54321'];
  }
  if (feeling === 'Overwhelmed' || feeling === 'Very stressed') {
    return ACTIVITIES['breathing-426'];
  }
  if (trigger === 'Overthinking' || feeling === 'Low') {
    return ACTIVITIES['thought-bubbles'];
  }
  if (trigger === 'Tired / lack of sleep') {
    return ACTIVITIES['body-scan'];
  }
  
  if (stats && stats.bestActivityId && ACTIVITIES[stats.bestActivityId]) {
    return ACTIVITIES[stats.bestActivityId];
  }
  return ACTIVITIES['breathing-426'];
}

function calculateActivityStats(history) {
  if (!history || history.length === 0) return null;

  const activityMap = {};
  let totalReduction = 0;
  let validDeltas = 0;

  history.forEach(item => {
    const delta = (item.stressBefore || 0) - (item.stressAfter || 0);
    if (!activityMap[item.activityId]) {
      activityMap[item.activityId] = {
        title: item.activityTitle || ACTIVITIES[item.activityId]?.title || 'Reset Exercise',
        count: 0,
        totalDelta: 0
      };
    }
    activityMap[item.activityId].count++;
    activityMap[item.activityId].totalDelta += delta;
    totalReduction += delta;
    validDeltas++;
  });

  let bestActivityId = null;
  let bestAvgDelta = -999;

  Object.keys(activityMap).forEach(actId => {
    const data = activityMap[actId];
    const avg = data.totalDelta / data.count;
    if (avg > bestAvgDelta) {
      bestAvgDelta = avg;
      bestActivityId = actId;
    }
  });

  const avgReduction = validDeltas > 0 ? (totalReduction / validDeltas).toFixed(1) : 0;

  return {
    bestActivityId,
    bestActivityTitle: activityMap[bestActivityId]?.title || 'Breathing Exercises',
    bestAvgDelta: bestAvgDelta > 0 ? bestAvgDelta.toFixed(1) : '2.5',
    avgReduction,
    totalResets: history.length
  };
}

// ==========================================================================
// MAIN ROOT COMPONENT
// ==========================================================================

function App() {
  // --- Persistent App State ---
  const [appState, setAppState] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Storage read error:', e);
    }
    return DEFAULT_INITIAL_STATE;
  });

  // --- Authenticated User State ---
  // NOTE: this is now populated from the verified backend session
  // (GET /api/auth/me on load, POST /api/auth/google on login), not
  // decoded client-side. We still keep it in localStorage as a cache
  // so the UI doesn't flash logged-out while /me is loading.
  const [user, setUser] = useState(() => {
    try {
      const savedUser = localStorage.getItem(USER_STORAGE_KEY);
      if (savedUser) return JSON.parse(savedUser);
    } catch (e) {
      console.warn('User storage read error:', e);
    }
    return null;
  });

  // On load, ask the backend who (if anyone) the current session belongs
  // to. This is the source of truth — the cached localStorage user above
  // is only an optimistic placeholder.
  useEffect(() => {
    let cancelled = false;
    window.api.me()
      .then(({ user: sessionUser }) => {
        if (!cancelled) setUser(sessionUser);
      })
      .catch(() => {
        if (!cancelled) setUser(null);
      });
    return () => { cancelled = true; };
  }, []);

  // --- Google Client ID ---
  const [googleClientId, setGoogleClientId] = useState(() => {
    return localStorage.getItem(GOOGLE_CLIENT_ID_KEY) || DEFAULT_GOOGLE_CLIENT_ID;
  });

  // Save state updates
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(appState));
    } catch (e) {}
  }, [appState]);

  // Save User Authentication
  useEffect(() => {
    try {
      if (user) {
        localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(user));
      } else {
        localStorage.removeItem(USER_STORAGE_KEY);
      }
    } catch (e) {}
  }, [user]);

  // Save Google Client ID
  useEffect(() => {
    try {
      localStorage.setItem(GOOGLE_CLIENT_ID_KEY, googleClientId);
    } catch (e) {}
  }, [googleClientId]);

  // Apply Theme
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', appState.theme);
  }, [appState.theme]);

  // Audio Sync
  useEffect(() => {
    audioService.setMasterVolume(appState.soundEnabled ? appState.soundVolume : 0);
  }, [appState.soundEnabled, appState.soundVolume]);

  useEffect(() => {
    if (appState.soundEnabled) {
      audioService.playAmbient(appState.ambientSound);
    } else {
      audioService.stopAmbient();
    }
  }, [appState.ambientSound, appState.soundEnabled]);

  // --- Navigation & View States ---
  // views: 'landing' | 'login' | 'check-feeling' | 'check-trigger' | 'recommendation' | 'exercise' | 'post-check' | 'dashboard' | 'journal'
  const [currentView, setCurrentView] = useState('landing');
  const [selectedFeeling, setSelectedFeeling] = useState(null);
  const [selectedTrigger, setSelectedTrigger] = useState(null);
  const [currentActivity, setCurrentActivity] = useState(ACTIVITIES['breathing-426']);
  const [initialStressScore, setInitialStressScore] = useState(7);
  const [activeSession, setActiveSession] = useState(null);
  const [isInstantReset, setIsInstantReset] = useState(false);

  // Modals
  const [showSafetyModal, setShowSafetyModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [showQuickLogModal, setShowQuickLogModal] = useState(false);

  // Stats
  const stats = useMemo(() => calculateActivityStats(appState.resetsHistory), [appState.resetsHistory]);

  // --- Google Auth Handler ---
  // The Google button itself is unchanged. What changed: we no longer
  // decode the credential in the browser and trust it. We send the raw
  // credential to the backend, which verifies it with Google, upserts
  // the user in MySQL, and creates a server-side session. Only the
  // backend's verified response is used to set `user`.
  const handleGoogleSuccess = async (credentialResponse) => {
    try {
      const { user: verifiedUser } = await window.api.loginWithGoogle(credentialResponse.credential);
      setUser(verifiedUser);

      if (window.confetti) {
        window.confetti({ particleCount: 40, spread: 60, origin: { y: 0.6 } });
      }

      setCurrentView('dashboard');
    } catch (err) {
      console.error('Google Sign-in failed:', err);
      alert('Could not sign you in. Please try again.');
    }
  };

  const handleSignOut = async () => {
    if (window.google?.accounts?.id) {
      try {
        window.google.accounts.id.disableAutoSelect();
      } catch (e) {}
    }
    try {
      await window.api.logout();
    } catch (e) {
      console.warn('Logout request failed:', e);
    }
    setUser(null);
    setCurrentView('landing');
  };

  // --- Action Handlers ---
  const startQuickResetFlow = () => {
    setSelectedFeeling(null);
    setSelectedTrigger(null);
    setCurrentView('check-feeling');
  };

  const handleSelectFeeling = (feelingItem) => {
    setSelectedFeeling(feelingItem.name);
    setInitialStressScore(feelingItem.defaultStress);
    setCurrentView('check-trigger');
  };

  const handleSelectTrigger = (triggerName) => {
    setSelectedTrigger(triggerName);
    const recommended = getSmartRecommendation(selectedFeeling, triggerName, appState.resetsHistory);
    setCurrentActivity(recommended);
    setCurrentView('recommendation');
  };

  const startInstantReset = () => {
    audioService.init();
    setIsInstantReset(true);
    setSelectedFeeling('Overwhelmed');
    setSelectedTrigger('Instant Panic/Reset');
    setInitialStressScore(8);
    setCurrentActivity(ACTIVITIES['breathing-426']);
    setCurrentView('exercise');
  };

  const startExercise = (activity) => {
    audioService.init();
    setCurrentActivity(activity);
    setCurrentView('exercise');
  };

  const handleExerciseComplete = (sessionDetails) => {
    setActiveSession({
      activityId: currentActivity.id,
      activityTitle: currentActivity.title,
      feeling: selectedFeeling || 'Stressed',
      trigger: selectedTrigger || 'General Stress',
      stressBefore: initialStressScore,
      durationSec: sessionDetails?.durationSec || currentActivity.duration
    });
    setCurrentView('post-check');
  };

  const handleSavePostFeedback = (rating, newStressScore) => {
    if (rating === 'Much better' || rating === 'A little better') {
      if (window.confetti) {
        window.confetti({
          particleCount: 50,
          spread: 70,
          origin: { y: 0.6 }
        });
      }
    }

    const newEntry = {
      id: 'reset-' + Date.now(),
      timestamp: Date.now(),
      feeling: activeSession?.feeling || 'Stressed',
      trigger: activeSession?.trigger || 'Daily Stress',
      activityId: activeSession?.activityId || currentActivity.id,
      activityTitle: activeSession?.activityTitle || currentActivity.title,
      stressBefore: activeSession?.stressBefore || initialStressScore,
      stressAfter: newStressScore,
      rating: rating,
      durationSec: activeSession?.durationSec || currentActivity.duration
    };

    setAppState(prev => ({
      ...prev,
      resetsHistory: [newEntry, ...prev.resetsHistory]
    }));

    // Signed-in users also get this reset persisted server-side, split
    // across the three tables the backend defines. Guests keep working
    // purely off localStorage, unaffected.
    if (user) {
      window.api.createBreathingSession(newEntry.activityTitle, newEntry.durationSec).catch(console.warn);
      window.api.createStressRecord(newEntry.stressBefore).catch(console.warn);
      window.api.createStressRecord(newEntry.stressAfter).catch(console.warn);
      window.api.createJournalEntry(
        `${newEntry.feeling} — ${newEntry.trigger} (${newEntry.rating})`,
        newEntry.feeling
      ).catch(console.warn);
    }

    setIsInstantReset(false);
    setCurrentView('dashboard');
  };

  const deleteJournalEntry = (id) => {
    setAppState(prev => ({
      ...prev,
      resetsHistory: prev.resetsHistory.filter(item => item.id !== id)
    }));
  };

  const clearAllData = () => {
    if (window.confirm('Reset all your logs and start fresh? This will clear local history on this device.')) {
      setAppState({
        ...DEFAULT_INITIAL_STATE,
        resetsHistory: []
      });
    }
  };

  const exportDataJSON = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(appState, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `reset-wellness-backup-${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const importDataJSON = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target.result);
        if (parsed.resetsHistory) {
          setAppState(parsed);
          alert('Data imported successfully!');
        }
      } catch (err) {
        alert('Invalid JSON file format.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="relative min-h-screen flex flex-col justify-between selection:bg-indigo-500 selection:text-white">
      {/* Atmosphere Glow Orbs */}
      <div className="ambient-glow-orb-1"></div>
      <div className="ambient-glow-orb-2"></div>

      {/* HEADER & NAV */}
      <HeaderNav
        currentView={currentView}
        setCurrentView={setCurrentView}
        user={user}
        onSignOut={handleSignOut}
        onGoToLogin={() => setCurrentView('login')}
        onInstantReset={startInstantReset}
        onOpenSafety={() => setShowSafetyModal(true)}
        onOpenSettings={() => setShowSettingsModal(true)}
        theme={appState.theme}
        setTheme={(th) => setAppState(prev => ({ ...prev, theme: th }))}
        soundEnabled={appState.soundEnabled}
        toggleSound={() => setAppState(prev => ({ ...prev, soundEnabled: !prev.soundEnabled }))}
        ambientSound={appState.ambientSound}
        setAmbientSound={(snd) => setAppState(prev => ({ ...prev, ambientSound: snd }))}
      />

      {/* MAIN VIEW CONTAINER */}
      <main className="relative z-10 flex-grow max-w-5xl mx-auto w-full px-4 py-6 sm:py-10">
        {currentView === 'landing' && (
          <LandingView
            user={user}
            onStartQuickReset={startQuickResetFlow}
            onInstantReset={startInstantReset}
            onExplore={() => setCurrentView('dashboard')}
            onSelectDirectActivity={(act) => {
              setCurrentActivity(act);
              setSelectedFeeling('Focused');
              setSelectedTrigger('Micro-Break');
              setInitialStressScore(6);
              setCurrentView('exercise');
            }}
            stats={stats}
          />
        )}

        {currentView === 'login' && (
          <LoginView
            user={user}
            googleClientId={googleClientId}
            setGoogleClientId={setGoogleClientId}
            onGoogleSuccess={handleGoogleSuccess}
            onContinueAsGuest={() => setCurrentView('landing')}
            onBack={() => setCurrentView('landing')}
          />
        )}

        {currentView === 'check-feeling' && (
          <FeelingCheckView
            onSelectFeeling={handleSelectFeeling}
            onBack={() => setCurrentView('landing')}
            onInstantReset={startInstantReset}
          />
        )}

        {currentView === 'check-trigger' && (
          <TriggerCheckView
            selectedFeeling={selectedFeeling}
            onSelectTrigger={handleSelectTrigger}
            onBack={() => setCurrentView('check-feeling')}
          />
        )}

        {currentView === 'recommendation' && (
          <RecommendationView
            feeling={selectedFeeling}
            trigger={selectedTrigger}
            activity={currentActivity}
            onStart={() => startExercise(currentActivity)}
            onChangeActivity={(act) => setCurrentActivity(act)}
            onBack={() => setCurrentView('check-trigger')}
          />
        )}

        {currentView === 'exercise' && (
          <ExerciseEngine
            activity={currentActivity}
            isInstantReset={isInstantReset}
            onComplete={handleExerciseComplete}
            onCancel={() => setCurrentView(isInstantReset ? 'landing' : 'recommendation')}
            soundEnabled={appState.soundEnabled}
          />
        )}

        {currentView === 'post-check' && (
          <PostCheckView
            initialStress={initialStressScore}
            activityTitle={currentActivity.title}
            onSaveFeedback={handleSavePostFeedback}
          />
        )}

        {currentView === 'dashboard' && (
          <DashboardView
            user={user}
            history={appState.resetsHistory}
            stats={stats}
            onStartQuickReset={startQuickResetFlow}
            onInstantReset={startInstantReset}
            onViewJournal={() => setCurrentView('journal')}
            onSelectActivity={(act) => {
              setCurrentActivity(act);
              setSelectedFeeling('Refreshed');
              setSelectedTrigger('Routine Reset');
              setInitialStressScore(6);
              setCurrentView('exercise');
            }}
            onGoToLogin={() => setCurrentView('login')}
          />
        )}

        {currentView === 'journal' && (
          <JournalView
            user={user}
            history={appState.resetsHistory}
            onDeleteEntry={deleteJournalEntry}
            onBack={() => setCurrentView('dashboard')}
            onOpenQuickLog={() => setShowQuickLogModal(true)}
            onExport={exportDataJSON}
            onImport={importDataJSON}
          />
        )}
      </main>

      {/* FOOTER */}
      <FooterNav
        user={user}
        onOpenSafety={() => setShowSafetyModal(true)}
        onOpenSettings={() => setShowSettingsModal(true)}
        onViewDashboard={() => setCurrentView('dashboard')}
        onGoToLogin={() => setCurrentView('login')}
      />

      {/* MODALS */}
      {showSafetyModal && (
        <SafetyModal onClose={() => setShowSafetyModal(false)} />
      )}

      {showSettingsModal && (
        <SettingsModal
          user={user}
          onSignOut={handleSignOut}
          googleClientId={googleClientId}
          setGoogleClientId={setGoogleClientId}
          theme={appState.theme}
          setTheme={(th) => setAppState(prev => ({ ...prev, theme: th }))}
          soundEnabled={appState.soundEnabled}
          toggleSound={() => setAppState(prev => ({ ...prev, soundEnabled: !prev.soundEnabled }))}
          soundVolume={appState.soundVolume}
          setSoundVolume={(v) => setAppState(prev => ({ ...prev, soundVolume: v }))}
          ambientSound={appState.ambientSound}
          setAmbientSound={(snd) => setAppState(prev => ({ ...prev, ambientSound: snd }))}
          onClearData={clearAllData}
          onExport={exportDataJSON}
          onImport={importDataJSON}
          onClose={() => setShowSettingsModal(false)}
        />
      )}

      {showQuickLogModal && (
        <QuickLogModal
          onSave={(entry) => {
            setAppState(prev => ({
              ...prev,
              resetsHistory: [entry, ...prev.resetsHistory]
            }));
            setShowQuickLogModal(false);
          }}
          onClose={() => setShowQuickLogModal(false)}
        />
      )}
    </div>
  );
}

// ==========================================================================
// 1. HEADER COMPONENT WITH PROFILE DROPDOWN
// ==========================================================================

function HeaderNav({ currentView, setCurrentView, user, onSignOut, onGoToLogin, onInstantReset, onOpenSafety, onOpenSettings, theme, setTheme, soundEnabled, toggleSound, ambientSound, setAmbientSound }) {
  const [showAmbientMenu, setShowAmbientMenu] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  useEffect(() => {
    if (window.lucide) window.lucide.createIcons();
  }, [user, showProfileMenu]);

  return (
    <header className="sticky top-0 z-40 glass-nav border-b border-white/10 px-4 py-3">
      <div className="max-w-6xl mx-auto flex items-center justify-between">
        {/* Logo */}
        <div 
          onClick={() => setCurrentView('landing')} 
          className="flex items-center space-x-2.5 cursor-pointer group"
          id="btn-nav-logo"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-500 via-purple-500 to-pink-500 flex items-center justify-center shadow-lg shadow-indigo-500/25 group-hover:scale-105 transition-transform">
            <i data-lucide="sparkles" className="w-5 h-5 text-white"></i>
          </div>
          <div>
            <span className="font-extrabold text-xl tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white via-slate-100 to-indigo-200">
              Reset
            </span>
            <span className="hidden sm:inline-block ml-2 text-xs px-2 py-0.5 rounded-full bg-white/10 text-slate-300 font-medium">
              Zero-Friction
            </span>
          </div>
        </div>

        {/* Action Center */}
        <div className="flex items-center space-x-2 sm:space-x-3">
          {/* Top Instant Reset Panic Button */}
          <button
            onClick={onInstantReset}
            id="btn-instant-reset-header"
            className="instant-pulse-btn flex items-center space-x-1.5 px-3.5 py-1.5 rounded-full text-white font-semibold text-xs sm:text-sm tracking-wide shadow-lg cursor-pointer"
            title="Immediate 60s Calming Reset with zero questions"
          >
            <span className="text-amber-300 text-sm">⚡</span>
            <span>I need a reset</span>
          </button>

          {/* Ambient Sound Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowAmbientMenu(!showAmbientMenu)}
              id="btn-ambient-toggle"
              className={`p-2 rounded-xl border transition-all ${
                ambientSound !== 'none' && soundEnabled
                  ? 'bg-indigo-600/30 border-indigo-400/50 text-indigo-300'
                  : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
              }`}
              title="Ambient Soundscape"
            >
              <i data-lucide={soundEnabled && ambientSound !== 'none' ? "volume-2" : "volume-x"} className="w-4 h-4"></i>
            </button>

            {showAmbientMenu && (
              <div className="absolute right-0 mt-2 w-48 rounded-2xl glass-panel p-2 shadow-2xl z-50 border border-white/15">
                <div className="text-[11px] font-semibold text-slate-400 px-3 py-1 uppercase tracking-wider">
                  Ambient Atmosphere
                </div>
                {[
                  { id: 'none', label: 'Muted', icon: 'volume-x' },
                  { id: 'rain', label: 'Gentle Rain', icon: 'cloud-rain' },
                  { id: 'waves', label: 'Ocean Waves', icon: 'waves' },
                  { id: 'bowl', label: 'Singing Bowl (432Hz)', icon: 'bell' }
                ].map((s) => (
                  <button
                    key={s.id}
                    onClick={() => {
                      setAmbientSound(s.id);
                      setShowAmbientMenu(false);
                    }}
                    className={`w-full flex items-center space-x-2 px-3 py-2 text-xs rounded-xl text-left transition-colors ${
                      ambientSound === s.id
                        ? 'bg-indigo-500/25 text-indigo-200 font-semibold'
                        : 'text-slate-300 hover:bg-white/10'
                    }`}
                  >
                    <i data-lucide={s.icon} className="w-3.5 h-3.5"></i>
                    <span>{s.label}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Dashboard Link */}
          <button
            onClick={() => setCurrentView('dashboard')}
            id="btn-nav-dashboard"
            className={`px-3 py-1.5 rounded-xl text-xs sm:text-sm font-medium transition-all ${
              currentView === 'dashboard' || currentView === 'journal'
                ? 'bg-white/15 text-white border border-white/20'
                : 'text-slate-300 hover:bg-white/5'
            }`}
          >
            Insights
          </button>

          {/* GOOGLE USER PROFILE / LOGIN BUTTON */}
          {user ? (
            <div className="relative">
              <button
                onClick={() => setShowProfileMenu(!showProfileMenu)}
                className="flex items-center space-x-2 p-1 pl-2 pr-3 rounded-2xl glass-panel hover:bg-white/15 border border-indigo-400/40 transition-all cursor-pointer"
                id="btn-user-profile-dropdown"
              >
                <img
                  src={user.picture}
                  alt={user.name}
                  className="w-7 h-7 rounded-full object-cover border border-emerald-400 shadow-sm"
                  onError={(e) => { e.target.src = 'https://api.dicebear.com/7.x/bottts/svg?seed=user'; }}
                />
                <span className="hidden sm:inline-block font-semibold text-xs text-white max-w-[90px] truncate">
                  {user.given_name || user.name.split(' ')[0]}
                </span>
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              </button>

              {showProfileMenu && (
                <div className="absolute right-0 mt-2 w-64 rounded-3xl glass-panel p-4 shadow-2xl z-50 border border-white/15 space-y-3 animate-fade-in text-left">
                  <div className="flex items-center space-x-3 pb-3 border-b border-white/10">
                    <img
                      src={user.picture}
                      alt={user.name}
                      className="w-11 h-11 rounded-full object-cover border-2 border-indigo-400"
                    />
                    <div className="overflow-hidden">
                      <div className="font-bold text-sm text-white truncate">{user.name}</div>
                      <div className="text-[11px] text-slate-400 truncate">{user.email}</div>
                    </div>
                  </div>

                  <div className="space-y-1 text-xs">
                    <div className="flex items-center justify-between text-slate-300 py-1">
                      <span>Account Status:</span>
                      <span className="text-emerald-400 font-semibold flex items-center space-x-1">
                        <span>●</span> <span>Google Verified</span>
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-slate-300 py-1">
                      <span>Cloud Sync:</span>
                      <span className="text-indigo-300 font-medium">Active</span>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-white/10 space-y-1.5">
                    <button
                      onClick={() => {
                        setShowProfileMenu(false);
                        setCurrentView('journal');
                      }}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs text-slate-200 hover:bg-white/10 flex items-center space-x-2"
                    >
                      <i data-lucide="book-open" className="w-3.5 h-3.5 text-indigo-400"></i>
                      <span>My Mood Journal</span>
                    </button>
                    <button
                      onClick={() => {
                        setShowProfileMenu(false);
                        onSignOut();
                      }}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs text-rose-300 hover:bg-rose-500/15 flex items-center space-x-2"
                    >
                      <i data-lucide="log-out" className="w-3.5 h-3.5"></i>
                      <span>Sign Out</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <button
              onClick={onGoToLogin}
              id="btn-header-signin"
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 border border-white/15 text-white font-semibold text-xs transition-all shadow-sm cursor-pointer"
            >
              <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
              </svg>
              <span>Sign In</span>
            </button>
          )}

          {/* Settings button */}
          <button
            onClick={onOpenSettings}
            id="btn-nav-settings"
            className="p-2 rounded-xl bg-white/5 border border-white/10 text-slate-300 hover:bg-white/10 transition-colors"
            title="Settings & Themes"
          >
            <i data-lucide="sliders" className="w-4 h-4"></i>
          </button>
        </div>
      </div>
    </header>
  );
}

// ==========================================================================
// 2. DEDICATED LOGIN / GOOGLE AUTHENTICATION VIEW
// ==========================================================================

function LoginView({ user, googleClientId, setGoogleClientId, onGoogleSuccess, onContinueAsGuest, onBack }) {
  const [showConfigHelper, setShowConfigHelper] = useState(false);
  const [customClientIdInput, setCustomClientIdInput] = useState(googleClientId);
  const [isGisReady, setIsGisReady] = useState(false);
  const googleBtnContainerRef = useRef(null);

  useEffect(() => {
    if (window.lucide) window.lucide.createIcons();
  }, [showConfigHelper, isGisReady]);

  useEffect(() => {
    const initGoogleIdentity = () => {
      if (window.google?.accounts?.id && googleClientId) {
        try {
          window.google.accounts.id.initialize({
            client_id: googleClientId,
            callback: onGoogleSuccess,
            auto_select: false,
            cancel_on_tap_outside: true
          });

          if (googleBtnContainerRef.current) {
            googleBtnContainerRef.current.innerHTML = '';
            window.google.accounts.id.renderButton(googleBtnContainerRef.current, {
              theme: 'outline',
              size: 'large',
              type: 'standard',
              shape: 'pill',
              text: 'signin_with',
              logo_alignment: 'left',
              width: 320
            });
          }
          setIsGisReady(true);
        } catch (e) {
          console.warn('Google Identity initialization notice:', e);
          setIsGisReady(false);
        }
      } else {
        setIsGisReady(false);
        setTimeout(initGoogleIdentity, 300);
      }
    };
    initGoogleIdentity();
  }, [googleClientId, onGoogleSuccess]);

  const handleSaveClientId = (e) => {
    e.preventDefault();
    if (customClientIdInput.trim()) {
      setGoogleClientId(customClientIdInput.trim());
      setShowConfigHelper(false);
      alert('Google Client ID updated!');
    }
  };

  return (
    <div className="login-page max-w-lg mx-auto animate-fade-in py-3 sm:py-8 px-2">
      <button onClick={onBack} className="login-back-btn">
        <i data-lucide="arrow-left" className="w-4 h-4"></i>
        <span>Back to App</span>
      </button>

      <div className="login-card glass-panel rounded-[2rem] border border-indigo-400/20 shadow-2xl overflow-hidden">
        <div className="login-glow"></div>

        <div className="relative z-10 p-6 sm:p-10 text-center">
          <div className="login-logo mx-auto mb-6">
            <div className="login-logo-ring"></div>
            <i data-lucide="sparkles" className="w-8 h-8 text-white"></i>
          </div>

          <div className="mb-8">
            <p className="login-eyebrow">A calmer moment starts here</p>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mt-2">Welcome back</h2>
            <p className="text-sm text-slate-300 max-w-sm mx-auto leading-relaxed mt-3">
              Sign in to keep your calming journey, reflections, and progress connected across your devices.
            </p>
          </div>

          <div className="login-benefits">
            <div><i data-lucide="cloud" className="w-4 h-4"></i><span>Save your progress</span></div>
            <div><i data-lucide="lock" className="w-4 h-4"></i><span>Private & secure</span></div>
            <div><i data-lucide="sparkles" className="w-4 h-4"></i><span>Personalized experience</span></div>
          </div>

          <div className="login-divider"><span>CONTINUE WITH</span></div>

          <div className="login-google-area">
            <div ref={googleBtnContainerRef} id="google-signin-btn-container" className="google-btn-wrap"></div>
            {!isGisReady && (
              <div className="text-xs text-slate-500 mt-2">Google sign-in is loading…</div>
            )}
          </div>

          <div className="login-or"><span>or</span></div>

          <button onClick={onContinueAsGuest} id="btn-continue-as-guest" className="login-guest-btn">
            <span className="login-guest-icon"><i data-lucide="wind" className="w-4 h-4"></i></span>
            <span className="flex-1 text-left">
              <strong>Continue as Guest</strong>
              <small>Start a quick 30-second reset without signing in</small>
            </span>
            <i data-lucide="arrow-right" className="w-4 h-4"></i>
          </button>

          <p className="login-note mt-5">
            You can use the app without an account. Sign in only when you want your progress synced.
          </p>
        </div>
      </div>

      <div className="mt-4">
        <div className="glass-panel rounded-2xl border border-white/10 overflow-hidden">
          <button onClick={() => setShowConfigHelper(!showConfigHelper)} className="w-full px-4 py-3 flex items-center justify-between text-xs text-slate-400 hover:text-white transition-colors">
            <span className="flex items-center gap-2"><i data-lucide="settings-2" className="w-3.5 h-3.5"></i> Google sign-in setup</span>
            <i data-lucide={showConfigHelper ? 'chevron-up' : 'chevron-down'} className="w-4 h-4"></i>
          </button>
          {showConfigHelper && (
            <div className="px-4 pb-4 pt-1 text-left border-t border-white/10">
              <p className="text-[11px] text-slate-500 leading-relaxed mb-3">
                Paste your Google OAuth 2.0 Web Client ID if you have one configured for this website.
              </p>
              <form onSubmit={handleSaveClientId} className="flex gap-2">
                <input type="text" value={customClientIdInput} onChange={(e) => setCustomClientIdInput(e.target.value)} placeholder="YOUR_CLIENT_ID.apps.googleusercontent.com" className="flex-1 min-w-0 px-3 py-2 rounded-xl bg-slate-950/70 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-indigo-400" />
                <button type="submit" className="px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs">Save</button>
              </form>
            </div>
          )}
        </div>
      </div>

      <div className="login-privacy mt-4">
        <i data-lucide="shield-check" className="w-4 h-4 text-emerald-400 flex-shrink-0"></i>
        <span>Google only shares the profile information your sign-in flow requests. Your account is never posted publicly.</span>
      </div>
    </div>
  );
}

// ========================================================================== 
// 3. LANDING VIEW
// ========================================================================== 
function LandingView({ user, onStartQuickReset, onInstantReset, onExplore, onSelectDirectActivity, stats }) {
  useEffect(() => {
    if (window.lucide) window.lucide.createIcons();
  }, [user]);

  return (
    <div className="flex flex-col items-center text-center space-y-10 py-6 sm:py-12 animate-fade-in">
      {/* Top User Greeting Pill */}
      {user ? (
        <div className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/25 text-emerald-300 text-xs font-medium backdrop-blur-md">
          <img src={user.picture} alt={user.name} className="w-4 h-4 rounded-full" />
          <span>Welcome back, {user.given_name || user.name.split(' ')[0]} • Ready for a calm moment?</span>
        </div>
      ) : (
        <div className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/25 text-indigo-300 text-xs font-medium backdrop-blur-md">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
          <span>Zero friction • No account required • 30-second relief</span>
        </div>
      )}

      {/* Main Headline */}
      <div className="space-y-4 max-w-2xl">
        <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-white leading-tight">
          Feeling overwhelmed? <br />
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-indigo-300 via-purple-200 to-teal-200">
            Let’s reset.
          </span>
        </h1>
        <p className="text-base sm:text-xl text-slate-300 max-w-xl mx-auto leading-relaxed">
          A quick, private space to calm your mind, regulate your nervous system, and feel a little better in under 60 seconds.
        </p>
      </div>

      {/* Core Action CTAs */}
      <div className="flex flex-col sm:flex-row items-center gap-4 w-full max-w-md mx-auto">
        <button
          onClick={onStartQuickReset}
          id="btn-start-quick-reset-hero"
          className="w-full sm:w-auto flex-1 flex items-center justify-center space-x-2 px-7 py-4 rounded-2xl bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-bold text-base shadow-xl shadow-indigo-500/30 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
        >
          <i data-lucide="sparkles" className="w-5 h-5"></i>
          <span>Start a Quick Reset</span>
        </button>

        <button
          onClick={onExplore}
          id="btn-explore-hero"
          className="w-full sm:w-auto px-6 py-4 rounded-2xl glass-panel text-slate-200 font-semibold text-base hover:bg-white/10 hover:text-white transition-all cursor-pointer"
        >
          Explore the App
        </button>
      </div>

      {/* Instant 1-Tap Emergency Banner */}
      <div className="w-full max-w-xl glass-panel p-5 rounded-3xl border border-amber-500/30 bg-amber-500/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-left">
        <div className="flex items-center space-x-3.5">
          <div className="w-11 h-11 rounded-2xl bg-amber-500/20 text-amber-300 flex items-center justify-center flex-shrink-0 text-xl font-bold">
            ⚡
          </div>
          <div>
            <div className="font-bold text-white text-sm">Need immediate calm right now?</div>
            <div className="text-xs text-slate-300">Skip all questions. Jump straight into 60s breathing.</div>
          </div>
        </div>
        <button
          onClick={onInstantReset}
          id="btn-instant-hero-cta"
          className="w-full sm:w-auto px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs tracking-wide transition-all shadow-md flex-shrink-0"
        >
          1-Tap Reset
        </button>
      </div>

      {/* Quick Direct Calming Micro-Tools Grid */}
      <div className="w-full max-w-3xl pt-4">
        <div className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-4 text-left px-2">
          Instant Calming Micro-Exercises
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { act: ACTIVITIES['breathing-426'], icon: 'wind', label: '60s Breath', time: '1 min', color: 'from-blue-500/20 to-indigo-500/20' },
            { act: ACTIVITIES['grounding-54321'], icon: 'anchor', label: '5-4-3-2-1 Ground', time: '90 sec', color: 'from-emerald-500/20 to-teal-500/20' },
            { act: ACTIVITIES['thought-bubbles'], icon: 'sparkles', label: 'Pop Worries', time: '1 min', color: 'from-purple-500/20 to-pink-500/20' },
            { act: ACTIVITIES['body-scan'], icon: 'smile', label: 'Un-Clench', time: '75 sec', color: 'from-amber-500/20 to-orange-500/20' }
          ].map((item, idx) => (
            <div
              key={idx}
              onClick={() => onSelectDirectActivity(item.act)}
              className="glass-panel p-4 rounded-2xl text-left cursor-pointer select-card-btn group"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="p-2 rounded-xl bg-white/10 group-hover:bg-indigo-500/30 text-indigo-300 transition-colors">
                  <i data-lucide={item.icon} className="w-4 h-4"></i>
                </div>
                <span className="text-[11px] text-slate-400">{item.time}</span>
              </div>
              <div className="font-semibold text-sm text-white group-hover:text-indigo-200 transition-colors">
                {item.label}
              </div>
              <div className="text-[11px] text-slate-400 mt-1 line-clamp-1">
                {item.act.tag}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Safety & Non-clinical pledge */}
      <div className="text-xs text-slate-400 max-w-lg mx-auto flex items-center justify-center space-x-2 pt-2">
        <i data-lucide="shield-check" className="w-4 h-4 text-indigo-400"></i>
        <span>100% private, runs entirely on your device. Never medical advice.</span>
      </div>
    </div>
  );
}

// ==========================================================================
// 4. STEP 1: FEELING CHECK VIEW
// ==========================================================================

function FeelingCheckView({ onSelectFeeling, onBack, onInstantReset }) {
  useEffect(() => {
    if (window.lucide) window.lucide.createIcons();
  }, []);

  const feelings = [
    { name: 'Very stressed', emoji: '😰', defaultStress: 9, subtitle: 'Heart racing or tight chest', color: 'hover:border-rose-400/60' },
    { name: 'Stressed', emoji: '😟', defaultStress: 7, subtitle: 'Tense, unsettled, uneasy', color: 'hover:border-amber-400/60' },
    { name: 'Okay', emoji: '😐', defaultStress: 5, subtitle: 'Just need a brief pause', color: 'hover:border-teal-400/60' },
    { name: 'Low', emoji: '😔', defaultStress: 6, subtitle: 'Drained, heavy, disconnected', color: 'hover:border-indigo-400/60' },
    { name: 'Angry', emoji: '😡', defaultStress: 8, subtitle: 'Irritated, heated, frustrated', color: 'hover:border-rose-500/60' },
    { name: 'Overwhelmed', emoji: '🤯', defaultStress: 10, subtitle: 'Too much happening at once', color: 'hover:border-purple-400/60' }
  ];

  return (
    <div className="max-w-2xl mx-auto space-y-8 animate-fade-in py-4">
      <div className="flex items-center justify-between text-xs text-slate-400">
        <button onClick={onBack} className="flex items-center space-x-1 hover:text-white transition-colors">
          <i data-lucide="arrow-left" className="w-3.5 h-3.5"></i>
          <span>Back</span>
        </button>
        <span className="font-semibold text-indigo-300">Step 1 of 2</span>
        <button onClick={onInstantReset} className="text-amber-300 hover:underline flex items-center space-x-1">
          <span>Skip to instant calm</span>
          <span>⚡</span>
        </button>
      </div>

      <div className="text-center space-y-2">
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
          How are you feeling right now?
        </h2>
        <p className="text-sm text-slate-300">
          Tap the one that describes you best. No typing needed.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
        {feelings.map((item, idx) => (
          <button
            key={idx}
            onClick={() => onSelectFeeling(item)}
            className={`glass-panel p-4 rounded-2xl flex items-center space-x-4 text-left select-card-btn ${item.color} group`}
          >
            <div className="text-3xl sm:text-4xl p-2 rounded-2xl bg-white/5 group-hover:scale-110 transition-transform">
              {item.emoji}
            </div>
            <div>
              <div className="font-bold text-base text-white group-hover:text-indigo-200 transition-colors">
                {item.name}
              </div>
              <div className="text-xs text-slate-400 mt-0.5">
                {item.subtitle}
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

// ==========================================================================
// 5. STEP 2: TRIGGER CHECK VIEW
// ==========================================================================

function TriggerCheckView({ selectedFeeling, onSelectTrigger, onBack }) {
  useEffect(() => {
    if (window.lucide) window.lucide.createIcons();
  }, []);

  const triggers = [
    { name: 'Studies / exams', emoji: '📚', desc: 'Deadlines, tests, grades, focus' },
    { name: 'Work', emoji: '💼', desc: 'Meetings, burnout, workload, bosses' },
    { name: 'Personal / relationship', emoji: '❤️', desc: 'Conflict, family, lonely, expectations' },
    { name: 'Overthinking', emoji: '🧠', desc: 'Replaying events, future anxiety' },
    { name: 'Tired / lack of sleep', emoji: '😴', desc: 'Brain fog, low energy, physical exhaustion' },
    { name: 'Anger', emoji: '😡', desc: 'Unfair situation, heated arguments' },
    { name: "I don't know", emoji: '❓', desc: 'Just feeling off and need quiet relief' }
  ];

  return (
    <div className="max-w-2xl mx-auto space-y-8 animate-fade-in py-4">
      <div className="flex items-center justify-between text-xs text-slate-400">
        <button onClick={onBack} className="flex items-center space-x-1 hover:text-white transition-colors">
          <i data-lucide="arrow-left" className="w-3.5 h-3.5"></i>
          <span>Back to feeling</span>
        </button>
        <span className="font-semibold text-indigo-300">Step 2 of 2</span>
        <span className="text-slate-400">Almost ready</span>
      </div>

      <div className="text-center space-y-2">
        <div className="inline-block text-xs font-semibold px-3 py-1 rounded-full bg-white/10 text-indigo-200">
          Feeling: {selectedFeeling}
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
          What is bothering you?
        </h2>
        <p className="text-sm text-slate-300">
          We’ll recommend the exact right micro-activity to help you reset.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
        {triggers.map((item, idx) => (
          <button
            key={idx}
            onClick={() => onSelectTrigger(item.name)}
            className="glass-panel p-4 rounded-2xl flex items-center space-x-4 text-left select-card-btn group"
          >
            <div className="text-3xl p-2 rounded-2xl bg-white/5 group-hover:scale-110 transition-transform">
              {item.emoji}
            </div>
            <div>
              <div className="font-bold text-sm sm:text-base text-white group-hover:text-indigo-200 transition-colors">
                {item.name}
              </div>
              <div className="text-xs text-slate-400 mt-0.5">
                {item.desc}
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

// ==========================================================================
// 6. RECOMMENDATION VIEW (1 Suitable Activity)
// ==========================================================================

function RecommendationView({ feeling, trigger, activity, onStart, onChangeActivity, onBack }) {
  const [showAlternates, setShowAlternates] = useState(false);

  useEffect(() => {
    if (window.lucide) window.lucide.createIcons();
  }, [showAlternates]);

  return (
    <div className="max-w-xl mx-auto space-y-8 animate-fade-in py-4 text-center">
      <div className="flex items-center justify-between text-xs text-slate-400">
        <button onClick={onBack} className="flex items-center space-x-1 hover:text-white transition-colors">
          <i data-lucide="arrow-left" className="w-3.5 h-3.5"></i>
          <span>Change answers</span>
        </button>
        <span className="text-indigo-300 font-medium">Personalized for you</span>
      </div>

      <div className="space-y-2">
        <div className="text-xs uppercase tracking-wider font-semibold text-indigo-400">
          Your Tailored Reset
        </div>
        <h2 className="text-3xl font-extrabold text-white">
          Here is your 1-step reset
        </h2>
        <p className="text-sm text-slate-300">
          Tailored for <span className="text-white font-medium">{feeling}</span> triggered by <span className="text-white font-medium">{trigger}</span>.
        </p>
      </div>

      <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-indigo-500/30 text-left space-y-6 relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl"></div>

        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-3.5">
            <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 text-indigo-300 flex items-center justify-center text-xl">
              <i data-lucide={activity.icon || "wind"} className="w-6 h-6"></i>
            </div>
            <div>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 font-medium">
                {activity.tag}
              </span>
              <h3 className="text-xl font-bold text-white mt-1">
                {activity.title}
              </h3>
            </div>
          </div>
          <div className="text-xs font-semibold text-slate-400 px-3 py-1 rounded-full bg-white/5">
            ⏱️ {activity.duration}s
          </div>
        </div>

        <p className="text-sm text-slate-300 leading-relaxed">
          {activity.description}
        </p>

        <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 flex items-start space-x-2.5 text-xs text-indigo-200">
          <i data-lucide="info" className="w-4 h-4 flex-shrink-0 mt-0.5 text-indigo-400"></i>
          <span><strong>Why this works:</strong> {activity.why}</span>
        </div>

        <button
          onClick={onStart}
          id="btn-start-recommended-reset"
          className="w-full py-4 rounded-2xl bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-bold text-lg shadow-xl shadow-indigo-500/30 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer flex items-center justify-center space-x-2"
        >
          <i data-lucide="play" className="w-5 h-5 fill-current"></i>
          <span>Start Reset Now</span>
        </button>
      </div>

      <div>
        <button
          onClick={() => setShowAlternates(!showAlternates)}
          className="text-xs text-slate-400 hover:text-slate-200 transition-colors underline decoration-dotted"
        >
          {showAlternates ? 'Hide other options' : 'Prefer a different reset?'}
        </button>

        {showAlternates && (
          <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3 text-left animate-fade-in">
            {Object.values(ACTIVITIES).filter(a => a.id !== activity.id).map(act => (
              <div
                key={act.id}
                onClick={() => {
                  onChangeActivity(act);
                  setShowAlternates(false);
                }}
                className="glass-panel p-3.5 rounded-2xl cursor-pointer hover:border-indigo-400/50 transition-all flex items-center justify-between"
              >
                <div>
                  <div className="font-semibold text-sm text-white">{act.title}</div>
                  <div className="text-[11px] text-slate-400">{act.duration}s • {act.tag}</div>
                </div>
                <i data-lucide="chevron-right" className="w-4 h-4 text-slate-400"></i>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ==========================================================================
// 7. EXERCISE PLAYER ROUTER & ENGINES
// ==========================================================================

function ExerciseEngine({ activity, isInstantReset, onComplete, onCancel, soundEnabled }) {
  if (activity.type === 'grounding') {
    return <GroundingPlayer activity={activity} onComplete={onComplete} onCancel={onCancel} />;
  }
  if (activity.type === 'focus') {
    return <FocusResetPlayer activity={activity} onComplete={onComplete} onCancel={onCancel} />;
  }
  if (activity.type === 'body-scan') {
    return <BodyScanPlayer activity={activity} onComplete={onComplete} onCancel={onCancel} />;
  }
  if (activity.type === 'bubbles') {
    return <ThoughtBubblesPlayer activity={activity} onComplete={onComplete} onCancel={onCancel} />;
  }
  return <BreathingCirclePlayer activity={activity} isInstantReset={isInstantReset} onComplete={onComplete} onCancel={onCancel} soundEnabled={soundEnabled} />;
}

// --- INTERACTIVE BREATHING CIRCLE ---
function BreathingCirclePlayer({ activity, isInstantReset, onComplete, onCancel, soundEnabled }) {
  const pattern = activity.pattern || { inhale: 4, hold: 2, exhale: 6 };
  const totalDuration = activity.duration || 60;

  const [phase, setPhase] = useState('inhale');
  const [phaseSecondsLeft, setPhaseSecondsLeft] = useState(pattern.inhale);
  const [totalSecondsElapsed, setTotalSecondsElapsed] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [cycleCount, setCycleCount] = useState(1);

  useEffect(() => {
    if (soundEnabled) {
      audioService.playChime(phase);
    }
  }, [phase, soundEnabled]);

  useEffect(() => {
    if (isPaused) return;

    const timer = setInterval(() => {
      setTotalSecondsElapsed(prev => {
        const next = prev + 1;
        if (next >= totalDuration) {
          clearInterval(timer);
          onComplete({ durationSec: totalDuration });
        }
        return next;
      });

      setPhaseSecondsLeft(prev => {
        if (prev <= 1) {
          if (phase === 'inhale') {
            if (pattern.hold && pattern.hold > 0) {
              setPhase('hold');
              return pattern.hold;
            } else {
              setPhase('exhale');
              return pattern.exhale;
            }
          } else if (phase === 'hold') {
            setPhase('exhale');
            return pattern.exhale;
          } else if (phase === 'exhale') {
            if (pattern.holdPost && pattern.holdPost > 0) {
              setPhase('holdPost');
              return pattern.holdPost;
            } else {
              setCycleCount(c => c + 1);
              setPhase('inhale');
              return pattern.inhale;
            }
          } else if (phase === 'holdPost') {
            setCycleCount(c => c + 1);
            setPhase('inhale');
            return pattern.inhale;
          }
          return pattern.inhale;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [phase, isPaused, totalDuration, pattern, onComplete]);

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.code === 'Space') {
        e.preventDefault();
        setIsPaused(p => !p);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    if (window.lucide) window.lucide.createIcons();
  }, [isPaused]);

  let circleScale = 1;
  let instruction = 'Breathe in slowly through your nose...';
  let phaseColor = 'from-teal-400 to-cyan-500';

  if (phase === 'inhale') {
    circleScale = 1.35;
    instruction = 'Breathe in gently through your nose...';
    phaseColor = 'from-teal-400 to-cyan-500';
  } else if (phase === 'hold' || phase === 'holdPost') {
    circleScale = 1.35;
    instruction = 'Hold peacefully...';
    phaseColor = 'from-indigo-400 to-purple-500';
  } else if (phase === 'exhale') {
    circleScale = 0.85;
    instruction = 'Exhale slowly through your mouth...';
    phaseColor = 'from-purple-400 to-pink-500';
  }

  const progressPercent = Math.min(100, (totalSecondsElapsed / totalDuration) * 100);

  return (
    <div className="max-w-xl mx-auto flex flex-col items-center text-center space-y-6 py-4 animate-fade-in">
      <div className="w-full flex items-center justify-between text-xs text-slate-400 px-2">
        <span className="flex items-center space-x-1.5 font-medium text-slate-300">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>Cycle {cycleCount}</span>
        </span>

        {isInstantReset && (
          <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-semibold text-[11px]">
            ⚡ Instant Reset Mode
          </span>
        )}

        <span>{Math.max(0, totalDuration - totalSecondsElapsed)}s left</span>
      </div>

      <div>
        <h2 className="text-xl sm:text-2xl font-bold text-white">
          {activity.title}
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Follow the expanding and contracting rhythm.
        </p>
      </div>

      <div className="breathing-canvas-container my-4">
        <div
          className="breathing-halo"
          style={{
            transform: `scale(${circleScale * 1.15})`,
            transition: `transform ${phase === 'inhale' ? pattern.inhale : phase === 'exhale' ? pattern.exhale : 0.8}s cubic-bezier(0.4, 0, 0.2, 1)`
          }}
        ></div>

        <div className="ripple-circle"></div>

        <div
          className={`relative z-10 w-44 h-44 sm:w-52 sm:h-52 rounded-full bg-gradient-to-tr ${phaseColor} flex flex-col items-center justify-center shadow-2xl text-white select-none transition-all`}
          style={{
            transform: `scale(${circleScale})`,
            transition: `transform ${phase === 'inhale' ? pattern.inhale : phase === 'exhale' ? pattern.exhale : 0.8}s cubic-bezier(0.4, 0, 0.2, 1)`
          }}
        >
          <div className="text-xs uppercase font-extrabold tracking-widest opacity-80 mb-1">
            {phase.toUpperCase()}
          </div>
          <div className="text-4xl sm:text-5xl font-black font-mono">
            {phaseSecondsLeft}s
          </div>
        </div>
      </div>

      <div className="space-y-1 max-w-sm">
        <div className="text-lg sm:text-xl font-bold text-white transition-all">
          {instruction}
        </div>
        <div className="text-xs text-slate-400">
          Tip: Relax your jaw, drop your shoulders.
        </div>
      </div>

      <div className="w-full max-w-xs bg-white/10 h-1.5 rounded-full overflow-hidden">
        <div
          className="bg-indigo-400 h-full rounded-full transition-all duration-300"
          style={{ width: `${progressPercent}%` }}
        ></div>
      </div>

      <div className="flex items-center space-x-4 pt-2">
        <button
          onClick={() => setIsPaused(!isPaused)}
          id="btn-pause-breathing"
          className="flex items-center space-x-2 px-5 py-2.5 rounded-2xl glass-panel text-white font-semibold text-sm hover:bg-white/10 transition-all cursor-pointer"
        >
          <i data-lucide={isPaused ? "play" : "pause"} className="w-4 h-4"></i>
          <span>{isPaused ? 'Resume' : 'Pause'}</span>
        </button>

        <button
          onClick={onCancel}
          id="btn-stop-breathing"
          className="flex items-center space-x-1.5 px-4 py-2.5 rounded-2xl bg-white/5 text-slate-400 hover:text-white hover:bg-white/10 text-sm transition-all cursor-pointer"
        >
          <i data-lucide="x" className="w-4 h-4"></i>
          <span>Stop</span>
        </button>
      </div>

      <div className="text-[11px] text-slate-400">
        Press <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white font-mono text-[10px]">Space</kbd> to pause / resume
      </div>
    </div>
  );
}

// --- 5-4-3-2-1 GROUNDING PLAYER ---
function GroundingPlayer({ activity, onComplete, onCancel }) {
  const steps = [
    {
      num: 5,
      prompt: '5 things you can SEE around you',
      sub: 'Look around your room or space. Notice small details: a pattern, a shadow, a light reflection, an object.',
      icon: 'eye'
    },
    {
      num: 4,
      prompt: '4 things you can physically FEEL or TOUCH',
      sub: 'Feel your feet grounded on the floor, the texture of your clothes, the cool desk, or temperature on your skin.',
      icon: 'hand'
    },
    {
      num: 3,
      prompt: '3 things you can HEAR right now',
      sub: 'Listen deeply: room hum, distant traffic, computer fan, or the quiet sound of your own breath.',
      icon: 'headphones'
    },
    {
      num: 2,
      prompt: '2 things you can SMELL (or favorite scents)',
      sub: 'Notice the air, coffee, fresh breeze, or mentally recall the comforting scent of lavender or rain.',
      icon: 'wind'
    },
    {
      num: 1,
      prompt: '1 good thing you APPRECIATE right now',
      sub: 'A glass of water, taking this 60-second break, a supportive friend, or simply breathing in peace.',
      icon: 'heart'
    }
  ];

  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const currentStep = steps[currentStepIndex];

  useEffect(() => {
    if (window.lucide) window.lucide.createIcons();
  }, [currentStepIndex]);

  const handleNext = () => {
    audioService.playChime('inhale');
    if (currentStepIndex >= steps.length - 1) {
      onComplete({ durationSec: 90 });
    } else {
      setCurrentStepIndex(c => c + 1);
    }
  };

  return (
    <div className="max-w-xl mx-auto space-y-6 py-4 animate-fade-in text-center">
      <div className="flex items-center justify-between text-xs text-slate-400">
        <span>Step {currentStepIndex + 1} of 5</span>
        <button onClick={onCancel} className="hover:text-white">Exit</button>
      </div>

      <div className="space-y-1">
        <h2 className="text-2xl font-extrabold text-white">5-4-3-2-1 Grounding</h2>
        <p className="text-xs text-slate-300">Re-anchor your mind into physical reality.</p>
      </div>

      <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-teal-500/30 text-left space-y-6 shadow-2xl relative">
        <div className="flex items-center space-x-4">
          <div className="w-14 h-14 rounded-2xl bg-teal-500/20 text-teal-300 flex items-center justify-center text-3xl font-black font-mono">
            {currentStep.num}
          </div>
          <div>
            <div className="text-xs uppercase tracking-wider font-semibold text-teal-300">Sensory Anchor</div>
            <div className="text-lg sm:text-xl font-bold text-white">{currentStep.prompt}</div>
          </div>
        </div>

        <p className="text-sm text-slate-300 leading-relaxed bg-white/5 p-4 rounded-2xl border border-white/10">
          {currentStep.sub}
        </p>

        <button
          onClick={handleNext}
          id="btn-grounding-next"
          className="w-full py-4 rounded-2xl bg-gradient-to-r from-teal-500 to-emerald-600 text-white font-bold text-base shadow-xl shadow-teal-500/25 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer flex items-center justify-center space-x-2"
        >
          <span>{currentStepIndex >= steps.length - 1 ? 'Complete Grounding' : 'I noticed them → Next'}</span>
          <i data-lucide="check" className="w-5 h-5"></i>
        </button>
      </div>

      <div className="flex justify-center space-x-2">
        {steps.map((_, i) => (
          <div
            key={i}
            className={`w-3 h-3 rounded-full transition-all ${
              i === currentStepIndex
                ? 'bg-teal-400 scale-125'
                : i < currentStepIndex
                ? 'bg-teal-700'
                : 'bg-white/15'
            }`}
          ></div>
        ))}
      </div>
    </div>
  );
}

// --- 2-MINUTE FOCUS & RESET PLAYER ---
function FocusResetPlayer({ activity, onComplete, onCancel }) {
  const [secondsLeft, setSecondsLeft] = useState(120);
  const [isPaused, setIsPaused] = useState(false);

  const prompts = [
    'Take a deep breath and let your shoulders drop.',
    'Clear all tabs in your mind. This 2 minutes is purely for you.',
    'Notice any tension in your eyes and gently soften your gaze.',
    'You are completely capable of handling what is ahead, one step at a time.',
    'Steady, calm focus is returning.'
  ];

  const currentPromptIndex = Math.min(
    prompts.length - 1,
    Math.floor((120 - secondsLeft) / 24)
  );

  useEffect(() => {
    if (isPaused) return;
    const timer = setInterval(() => {
      setSecondsLeft(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          onComplete({ durationSec: 120 });
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [isPaused, onComplete]);

  const mins = Math.floor(secondsLeft / 60);
  const secs = secondsLeft % 60;

  return (
    <div className="max-w-md mx-auto space-y-8 py-6 text-center animate-fade-in">
      <div className="flex justify-between items-center text-xs text-slate-400">
        <span>2-Minute Reset & Clarity</span>
        <button onClick={onCancel} className="hover:text-white">Exit</button>
      </div>

      <div className="glass-panel p-8 rounded-3xl border border-indigo-500/30 space-y-6 shadow-2xl">
        <div className="text-5xl sm:text-6xl font-black font-mono text-white tracking-tight">
          {mins}:{secs < 10 ? '0' : ''}{secs}
        </div>

        <div className="min-h-[60px] flex items-center justify-center text-base sm:text-lg font-medium text-indigo-200 transition-all">
          "{prompts[currentPromptIndex]}"
        </div>

        <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden">
          <div
            className="bg-gradient-to-r from-indigo-400 to-purple-400 h-full transition-all duration-300"
            style={{ width: `${((120 - secondsLeft) / 120) * 100}%` }}
          ></div>
        </div>

        <div className="flex justify-center space-x-3 pt-2">
          <button
            onClick={() => setIsPaused(!isPaused)}
            className="px-6 py-2.5 rounded-2xl glass-panel text-white font-semibold text-sm hover:bg-white/10 transition-all"
          >
            {isPaused ? 'Resume' : 'Pause'}
          </button>
          <button
            onClick={() => onComplete({ durationSec: 120 - secondsLeft })}
            className="px-4 py-2.5 rounded-2xl bg-indigo-500/20 text-indigo-200 hover:bg-indigo-500/30 text-sm font-semibold transition-all"
          >
            Finished Early
          </button>
        </div>
      </div>
    </div>
  );
}

// --- BODY SCAN & UN-CLENCH PLAYER ---
function BodyScanPlayer({ activity, onComplete, onCancel }) {
  const steps = [
    { title: 'Jaw & Teeth', cue: 'Unclench your jaw. Let your teeth part slightly and let your tongue rest on the floor of your mouth.' },
    { title: 'Eyes & Forehead', cue: 'Smooth the furrow in your brow. Soften the muscles behind your eyelids and let your temples ease.' },
    { title: 'Shoulders & Neck', cue: 'Drop your shoulders down 2 inches away from your ears. Let your neck lengthen and release.' },
    { title: 'Stomach & Belly', cue: 'Release any holding in your abdominal muscles. Let your belly soften and expand naturally.' },
    { title: 'Hands & Palms', cue: 'Uncurl your fingers. Place your palms gently open and loose.' }
  ];

  const [step, setStep] = useState(0);

  const nextStep = () => {
    audioService.playChime('inhale');
    if (step >= steps.length - 1) {
      onComplete({ durationSec: 75 });
    } else {
      setStep(s => s + 1);
    }
  };

  return (
    <div className="max-w-xl mx-auto space-y-6 py-4 animate-fade-in text-center">
      <div className="flex justify-between items-center text-xs text-slate-400">
        <span>Somatic Relaxation ({step + 1}/{steps.length})</span>
        <button onClick={onCancel} className="hover:text-white">Exit</button>
      </div>

      <div className="glass-panel p-6 sm:p-8 rounded-3xl border border-amber-500/30 text-left space-y-6 shadow-2xl">
        <div className="flex items-center space-x-3">
          <div className="p-3 rounded-2xl bg-amber-500/20 text-amber-300 font-bold text-lg">
            🧘
          </div>
          <div>
            <div className="text-xs uppercase font-semibold text-amber-300">Focus Area</div>
            <h3 className="text-xl font-bold text-white">{steps[step].title}</h3>
          </div>
        </div>

        <p className="text-base text-slate-200 leading-relaxed bg-white/5 p-5 rounded-2xl border border-white/10">
          {steps[step].cue}
        </p>

        <button
          onClick={nextStep}
          className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-bold text-base hover:scale-[1.02] transition-all cursor-pointer shadow-lg"
        >
          {step >= steps.length - 1 ? 'Complete Relaxation' : 'Relaxed → Next Area'}
        </button>
      </div>
    </div>
  );
}

// --- THOUGHT BUBBLE POP MINI-TOOL ---
function ThoughtBubblesPlayer({ activity, onComplete, onCancel }) {
  const [bubbles, setBubbles] = useState([
    { id: 1, text: 'Deadline pressure', popped: false },
    { id: 2, text: 'Overthinking future', popped: false },
    { id: 3, text: 'Self-doubt', popped: false },
    { id: 4, text: 'Mental fatigue', popped: false },
    { id: 5, text: 'What others think', popped: false }
  ]);
  const [customText, setCustomText] = useState('');

  const popBubble = (id) => {
    audioService.playChime('hold');
    setBubbles(prev => prev.map(b => b.id === id ? { ...b, popped: true } : b));
  };

  const addCustomBubble = (e) => {
    e.preventDefault();
    if (!customText.trim()) return;
    setBubbles(prev => [...prev, { id: Date.now(), text: customText.trim(), popped: false }]);
    setCustomText('');
  };

  const remaining = bubbles.filter(b => !b.popped).length;

  return (
    <div className="max-w-xl mx-auto space-y-6 py-4 animate-fade-in text-center">
      <div className="flex justify-between items-center text-xs text-slate-400">
        <span>Worry Bubble Release</span>
        <button onClick={onCancel} className="hover:text-white">Exit</button>
      </div>

      <div className="space-y-1">
        <h2 className="text-2xl font-bold text-white">Tap worries to pop & dissolve them</h2>
        <p className="text-xs text-slate-300">Watch thoughts drift and disappear into stardust.</p>
      </div>

      <div className="min-h-[220px] flex flex-wrap items-center justify-center gap-3 p-4 glass-panel rounded-3xl border border-purple-500/25">
        {bubbles.map(b => !b.popped && (
          <div
            key={b.id}
            onClick={() => popBubble(b.id)}
            className="bubble-item px-4 py-2.5 rounded-full bg-gradient-to-r from-purple-500/30 to-pink-500/30 border border-purple-300/40 text-purple-100 text-sm font-semibold shadow-lg backdrop-blur-md cursor-pointer hover:border-pink-300"
          >
            💭 {b.text} ✕
          </div>
        ))}

        {remaining === 0 && (
          <div className="text-emerald-300 font-bold text-base animate-fade-in">
            ✨ All worries cleared! Your mental space is calm and open.
          </div>
        )}
      </div>

      <form onSubmit={addCustomBubble} className="flex gap-2">
        <input
          type="text"
          placeholder="Add another worry to pop..."
          value={customText}
          onChange={(e) => setCustomText(e.target.value)}
          className="flex-1 px-4 py-2.5 rounded-2xl bg-white/5 border border-white/10 text-white placeholder-slate-400 text-sm focus:outline-none focus:border-purple-400"
        />
        <button
          type="submit"
          className="px-4 py-2.5 rounded-2xl bg-purple-600 hover:bg-purple-500 text-white text-sm font-semibold transition-all"
        >
          Add Bubble
        </button>
      </form>

      <button
        onClick={() => onComplete({ durationSec: 60 })}
        className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold text-base hover:scale-[1.01] transition-all cursor-pointer shadow-lg"
      >
        Finished De-Cluttering
      </button>
    </div>
  );
}

// ==========================================================================
// 8. POST-RESET CHECK VIEW ("How do you feel now?")
// ==========================================================================

function PostCheckView({ initialStress, activityTitle, onSaveFeedback }) {
  const [selectedRating, setSelectedRating] = useState('Much better');
  const [newStressScore, setNewStressScore] = useState(Math.max(1, initialStress - 3));

  useEffect(() => {
    if (window.lucide) window.lucide.createIcons();
  }, []);

  const ratings = [
    { label: 'Much better', emoji: '😌', delta: -3, color: 'hover:border-emerald-400' },
    { label: 'A little better', emoji: '🙂', delta: -2, color: 'hover:border-teal-400' },
    { label: 'Same', emoji: '😐', delta: 0, color: 'hover:border-slate-400' },
    { label: 'Worse', emoji: '😞', delta: +1, color: 'hover:border-rose-400' }
  ];

  const handleSelect = (r) => {
    setSelectedRating(r.label);
    const score = Math.max(1, Math.min(10, initialStress + r.delta));
    setNewStressScore(score);
  };

  return (
    <div className="max-w-xl mx-auto space-y-8 animate-fade-in py-6 text-center">
      <div className="space-y-2">
        <div className="inline-flex items-center space-x-1 text-xs font-semibold px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300">
          <i data-lucide="check-circle" className="w-3.5 h-3.5"></i>
          <span>Reset Complete</span>
        </div>
        <h2 className="text-3xl font-extrabold text-white">
          How do you feel now?
        </h2>
        <p className="text-sm text-slate-300">
          Tracking this helps Reset learn what works best for your body and mind.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3.5">
        {ratings.map((r, i) => (
          <button
            key={i}
            onClick={() => handleSelect(r)}
            className={`glass-panel p-5 rounded-3xl flex flex-col items-center justify-center space-y-2 select-card-btn ${
              selectedRating === r.label
                ? 'border-indigo-400 bg-indigo-500/20 shadow-lg shadow-indigo-500/20'
                : r.color
            }`}
          >
            <span className="text-4xl">{r.emoji}</span>
            <span className="font-bold text-sm text-white">{r.label}</span>
          </button>
        ))}
      </div>

      <div className="glass-panel p-5 rounded-3xl border border-white/10 flex items-center justify-between">
        <div className="text-left">
          <div className="text-xs text-slate-400">Stress Before → Now</div>
          <div className="font-bold text-lg text-white">
            {initialStress}/10 <span className="text-indigo-300">→</span> <span className="text-emerald-400">{newStressScore}/10</span>
          </div>
        </div>
        <div className="text-right">
          <span className="text-xs px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 font-semibold">
            {initialStress - newStressScore > 0 ? `-${initialStress - newStressScore} points` : 'Logged'}
          </span>
        </div>
      </div>

      <button
        onClick={() => onSaveFeedback(selectedRating, newStressScore)}
        id="btn-save-post-feedback"
        className="w-full py-4 rounded-2xl bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-bold text-base shadow-xl shadow-indigo-500/30 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer flex items-center justify-center space-x-2"
      >
        <span>Save & View Insights</span>
        <i data-lucide="arrow-right" className="w-5 h-5"></i>
      </button>
    </div>
  );
}

// ==========================================================================
// 9. DASHBOARD & INSIGHTS VIEW
// ==========================================================================

function DashboardView({ user, history, stats, onStartQuickReset, onInstantReset, onViewJournal, onSelectActivity, onGoToLogin }) {
  const chartCanvasRef = useRef(null);
  const chartInstanceRef = useRef(null);

  useEffect(() => {
    if (window.lucide) window.lucide.createIcons();
  }, [user]);

  useEffect(() => {
    if (!chartCanvasRef.current || !window.Chart) return;

    const ctx = chartCanvasRef.current.getContext('2d');
    if (chartInstanceRef.current) {
      chartInstanceRef.current.destroy();
    }

    const recentData = [...history].reverse().slice(-7);
    const labels = recentData.map((d, i) => {
      const date = new Date(d.timestamp);
      return `${date.getMonth() + 1}/${date.getDate()}`;
    });

    const dataBefore = recentData.map(d => d.stressBefore || 7);
    const dataAfter = recentData.map(d => d.stressAfter || 4);

    chartInstanceRef.current = new window.Chart(ctx, {
      type: 'line',
      data: {
        labels: labels.length > 0 ? labels : ['Day 1', 'Day 2', 'Day 3'],
        datasets: [
          {
            label: 'Stress Before',
            data: dataBefore.length > 0 ? dataBefore : [8, 7, 8],
            borderColor: '#f43f5e',
            backgroundColor: 'rgba(244, 63, 94, 0.1)',
            borderDash: [5, 5],
            tension: 0.35,
            fill: false,
            pointRadius: 4
          },
          {
            label: 'Stress After Reset',
            data: dataAfter.length > 0 ? dataAfter : [4, 3, 4],
            borderColor: '#2dd4bf',
            backgroundColor: 'rgba(45, 212, 191, 0.15)',
            tension: 0.35,
            fill: true,
            pointRadius: 5
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'top',
            labels: { color: '#94a3b8', font: { family: 'Plus Jakarta Sans', size: 11 } }
          },
          tooltip: {
            backgroundColor: '#1e293b',
            titleColor: '#fff',
            bodyColor: '#cbd5e1'
          }
        },
        scales: {
          y: {
            min: 1,
            max: 10,
            grid: { color: 'rgba(255,255,255,0.06)' },
            ticks: { color: '#64748b' }
          },
          x: {
            grid: { color: 'rgba(255,255,255,0.06)' },
            ticks: { color: '#64748b' }
          }
        }
      }
    });

    return () => {
      if (chartInstanceRef.current) chartInstanceRef.current.destroy();
    };
  }, [history]);

  const latestEntry = history[0];

  return (
    <div className="space-y-8 animate-fade-in py-2">
      {/* Top Header with User Greeting */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
              {user ? `Hello, ${user.given_name || user.name.split(' ')[0]} 👋` : 'Your Wellness Insights'}
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-300">
            {user
              ? `Synced with Google account (${user.email})`
              : 'Private on-device trends of your daily calm progress.'}
          </p>
        </div>

        <div className="flex items-center space-x-2.5">
          {!user && (
            <button
              onClick={onGoToLogin}
              className="px-3 py-2 rounded-2xl bg-white/10 hover:bg-white/15 text-white font-semibold text-xs transition-all flex items-center space-x-1.5"
            >
              <span>Sync with Google</span>
            </button>
          )}
          <button
            onClick={onStartQuickReset}
            className="px-4 py-2 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition-all shadow-md flex items-center space-x-1.5"
          >
            <i data-lucide="sparkles" className="w-3.5 h-3.5"></i>
            <span>Quick Reset</span>
          </button>
          <button
            onClick={onViewJournal}
            className="px-4 py-2 rounded-2xl glass-panel text-slate-300 hover:text-white font-semibold text-xs transition-all flex items-center space-x-1.5"
          >
            <i data-lucide="book-open" className="w-3.5 h-3.5"></i>
            <span>Journal</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="glass-panel p-5 rounded-3xl border border-white/10 space-y-2">
          <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
            Latest Check-in
          </div>
          {latestEntry ? (
            <div>
              <div className="text-2xl font-black text-white">
                Stress: {latestEntry.stressBefore}/10 <span className="text-indigo-400">→</span> <span className="text-emerald-400">{latestEntry.stressAfter}/10</span>
              </div>
              <div className="text-xs text-slate-300 mt-1 flex items-center space-x-2">
                <span>{latestEntry.feelingEmoji || '😌'} {latestEntry.feeling}</span>
                <span>•</span>
                <span className="text-emerald-300">-{latestEntry.stressBefore - latestEntry.stressAfter} pts</span>
              </div>
            </div>
          ) : (
            <div className="text-sm text-slate-400">
              No check-ins yet today. Ready for a quick 60s reset?
            </div>
          )}
        </div>

        <div className="glass-panel p-5 rounded-3xl border border-indigo-500/30 md:col-span-2 space-y-2 relative overflow-hidden">
          <div className="text-xs font-semibold text-indigo-300 uppercase tracking-wider flex items-center space-x-1.5">
            <i data-lucide="award" className="w-3.5 h-3.5"></i>
            <span>Your Most Helpful Reset</span>
          </div>
          <div className="text-lg sm:text-xl font-bold text-white">
            {stats?.bestActivityTitle || 'Breathing exercises'}
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            {stats && stats.bestAvgDelta > 0
              ? `Based on your personal feedback, this exercise reduces your stress by ${stats.bestAvgDelta} points on average. It seems to work particularly well for you.`
              : 'Complete a few quick resets and Reset will highlight which techniques help you calm down fastest.'}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
        <div className="glass-panel p-4 rounded-2xl text-left">
          <div className="text-xs text-slate-400">Resets Done</div>
          <div className="text-2xl font-black text-white mt-1">{history.length}</div>
        </div>
        <div className="glass-panel p-4 rounded-2xl text-left">
          <div className="text-xs text-slate-400">Avg Reduction</div>
          <div className="text-2xl font-black text-emerald-400 mt-1">-{stats?.avgReduction || '3.2'} pts</div>
        </div>
        <div className="glass-panel p-4 rounded-2xl text-left">
          <div className="text-xs text-slate-400">Calm Minutes</div>
          <div className="text-2xl font-black text-indigo-300 mt-1">
            {Math.round(history.reduce((acc, c) => acc + (c.durationSec || 60), 0) / 60)}m
          </div>
        </div>
        <div className="glass-panel p-4 rounded-2xl text-left">
          <div className="text-xs text-slate-400">Sync Status</div>
          <div className="text-sm font-bold text-teal-300 mt-2 flex items-center space-x-1">
            <i data-lucide={user ? "cloud-check" : "shield"} className="w-3.5 h-3.5"></i>
            <span>{user ? 'Google Cloud' : '100% Local'}</span>
          </div>
        </div>
      </div>

      <div className="glass-panel p-6 rounded-3xl border border-white/10 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-bold text-base text-white">Stress Trend Over Time</h3>
            <p className="text-xs text-slate-400">Comparing stress levels before vs. after your resets</p>
          </div>
          <span className="text-xs px-2.5 py-1 rounded-full bg-white/5 text-slate-400">Last 7 resets</span>
        </div>

        <div className="h-64 w-full relative">
          <canvas ref={chartCanvasRef}></canvas>
        </div>
      </div>

      <div className="space-y-3">
        <div className="text-xs font-semibold uppercase tracking-wider text-slate-400">
          Quick Launch Exercises
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {[ACTIVITIES['breathing-426'], ACTIVITIES['grounding-54321'], ACTIVITIES['thought-bubbles']].map(act => (
            <div
              key={act.id}
              onClick={() => onSelectActivity(act)}
              className="glass-panel p-4 rounded-2xl flex items-center justify-between cursor-pointer select-card-btn group"
            >
              <div>
                <div className="font-bold text-sm text-white group-hover:text-indigo-200">{act.title}</div>
                <div className="text-xs text-slate-400 mt-0.5">{act.tag} • {act.duration}s</div>
              </div>
              <div className="p-2 rounded-xl bg-white/5 text-indigo-300 group-hover:bg-indigo-500/20">
                <i data-lucide="play" className="w-4 h-4"></i>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ==========================================================================
// 10. MOOD & STRESS JOURNAL VIEW
// ==========================================================================

function JournalView({ user, history, onDeleteEntry, onBack, onOpenQuickLog, onExport, onImport }) {
  const [searchTerm, setSearchTerm] = useState('');
  const fileInputRef = useRef(null);

  useEffect(() => {
    if (window.lucide) window.lucide.createIcons();
  }, [history, searchTerm, user]);

  const filtered = history.filter(item => {
    const q = searchTerm.toLowerCase();
    return (
      (item.feeling && item.feeling.toLowerCase().includes(q)) ||
      (item.trigger && item.trigger.toLowerCase().includes(q)) ||
      (item.activityTitle && item.activityTitle.toLowerCase().includes(q))
    );
  });

  return (
    <div className="space-y-6 animate-fade-in py-2">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <button onClick={onBack} className="p-2 rounded-xl glass-panel text-slate-300 hover:text-white">
            <i data-lucide="arrow-left" className="w-4 h-4"></i>
          </button>
          <div>
            <h2 className="text-2xl font-extrabold text-white">Mood & Reset Journal</h2>
            <p className="text-xs text-slate-300">
              {user ? `Private journal for ${user.name}` : 'Your private history of emotional check-ins.'}
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={onOpenQuickLog}
            className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center space-x-1.5"
          >
            <i data-lucide="plus" className="w-3.5 h-3.5"></i>
            <span>Quick Log</span>
          </button>
          <button
            onClick={onExport}
            className="p-2 rounded-xl glass-panel text-slate-300 hover:text-white"
            title="Export JSON Backup"
          >
            <i data-lucide="download" className="w-4 h-4"></i>
          </button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={onImport}
            accept=".json"
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current && fileInputRef.current.click()}
            className="p-2 rounded-xl glass-panel text-slate-300 hover:text-white"
            title="Import Backup"
          >
            <i data-lucide="upload" className="w-4 h-4"></i>
          </button>
        </div>
      </div>

      <div className="relative">
        <input
          type="text"
          placeholder="Filter by feeling, trigger (e.g. exams, work, overthinking)..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full px-4 py-3 rounded-2xl bg-white/5 border border-white/10 text-white placeholder-slate-400 text-sm focus:outline-none focus:border-indigo-400"
        />
      </div>

      <div className="space-y-3">
        {filtered.length > 0 ? (
          filtered.map(item => (
            <div
              key={item.id}
              className="glass-panel p-4 sm:p-5 rounded-2xl border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
            >
              <div className="flex items-start space-x-3.5">
                <div className="text-2xl p-2 rounded-2xl bg-white/5 flex-shrink-0">
                  {item.feelingEmoji || '😌'}
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-sm text-white">{item.feeling}</span>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-white/10 text-slate-300">
                      {item.trigger}
                    </span>
                  </div>
                  <div className="text-xs text-indigo-300 mt-1">
                    Activity: {item.activityTitle}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    {new Date(item.timestamp).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' })}
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between sm:justify-end space-x-4 border-t sm:border-t-0 pt-2 sm:pt-0 border-white/10">
                <div className="text-right">
                  <div className="text-xs text-slate-400">Stress Change</div>
                  <div className="font-bold text-sm text-white">
                    {item.stressBefore}/10 → <span className="text-emerald-400">{item.stressAfter}/10</span>
                  </div>
                </div>

                <button
                  onClick={() => onDeleteEntry(item.id)}
                  className="p-2 rounded-xl text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                  title="Delete entry"
                >
                  <i data-lucide="trash-2" className="w-4 h-4"></i>
                </button>
              </div>
            </div>
          ))
        ) : (
          <div className="glass-panel p-8 rounded-3xl text-center text-slate-400 space-y-2">
            <i data-lucide="inbox" className="w-8 h-8 mx-auto text-slate-500"></i>
            <div>No matching journal entries found.</div>
          </div>
        )}
      </div>
    </div>
  );
}

// ==========================================================================
// 11. QUICK LOG MODAL (5-Second Manual Entry)
// ==========================================================================

function QuickLogModal({ onSave, onClose }) {
  const [mood, setMood] = useState('Stressed');
  const [trigger, setTrigger] = useState('Work');
  const [stressScore, setStressScore] = useState(7);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave({
      id: 'log-' + Date.now(),
      timestamp: Date.now(),
      feeling: mood,
      feelingEmoji: mood === 'Very stressed' ? '😰' : mood === 'Stressed' ? '😟' : mood === 'Okay' ? '😐' : '🧠',
      trigger: trigger,
      activityId: 'manual-checkin',
      activityTitle: 'Manual Mood Check-in',
      stressBefore: stressScore,
      stressAfter: stressScore,
      rating: 'Logged',
      durationSec: 0
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="glass-panel w-full max-w-md p-6 rounded-3xl border border-white/15 space-y-5">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-bold text-white">Quick 5-Second Check-in</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white">✕</button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-xs text-slate-300 font-semibold block mb-1.5">Mood</label>
            <select
              value={mood}
              onChange={e => setMood(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-white text-sm"
            >
              <option value="Very stressed">😰 Very stressed</option>
              <option value="Stressed">😟 Stressed</option>
              <option value="Overthinking">🧠 Overthinking</option>
              <option value="Okay">😐 Okay</option>
              <option value="Low">😔 Low</option>
              <option value="Calm">😌 Calm</option>
            </select>
          </div>

          <div>
            <label className="text-xs text-slate-300 font-semibold block mb-1.5">Trigger</label>
            <select
              value={trigger}
              onChange={e => setTrigger(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-white/15 text-white text-sm"
            >
              <option value="Work">💼 Work</option>
              <option value="Studies / exams">📚 Studies / exams</option>
              <option value="Personal / relationship">❤️ Personal / relationship</option>
              <option value="Overthinking">🧠 Overthinking</option>
              <option value="Tired">😴 Tired</option>
              <option value="General">❓ General</option>
            </select>
          </div>

          <div>
            <div className="flex justify-between text-xs text-slate-300 mb-1 font-semibold">
              <span>Stress Level</span>
              <span className="text-indigo-300 font-bold">{stressScore}/10</span>
            </div>
            <input
              type="range"
              min="1"
              max="10"
              value={stressScore}
              onChange={e => setStressScore(Number(e.target.value))}
              className="w-full accent-indigo-500"
            />
          </div>

          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-md transition-all cursor-pointer"
          >
            Save Check-in
          </button>
        </form>
      </div>
    </div>
  );
}

// ==========================================================================
// 12. SAFETY & CRISIS SUPPORT MODAL ("Need more help?")
// ==========================================================================

function SafetyModal({ onClose }) {
  const [selectedCountry, setSelectedCountry] = useState('us');

  const lifelines = {
    us: [
      { name: '988 Suicide & Crisis Lifeline', contact: 'Call or Text 988', desc: 'Free, confidential 24/7 support across the United States.' },
      { name: 'Crisis Text Line', contact: 'Text HOME to 741741', desc: 'Free 24/7 crisis counseling via SMS.' },
      { name: 'The Trevor Project (LGBTQ youth)', contact: 'Call 1-866-488-7386', desc: '24/7 confidential suicide prevention lifeline.' }
    ],
    uk: [
      { name: 'NHS Mental Health Services', contact: 'Call 111 (or 999 in emergency)', desc: 'Immediate medical assessment and support.' },
      { name: 'Samaritans', contact: 'Call 116 123', desc: 'Free 24/7 helpline for emotional support.' },
      { name: 'Shout Crisis Text Line', contact: 'Text SHOUT to 85258', desc: 'Free 24/7 confidential text support.' }
    ],
    in: [
      { name: 'Tele-MANAS (Govt of India)', contact: 'Call 14416 or 1800-891-4416', desc: 'Toll-free 24/7 mental health helpline.' },
      { name: 'Vandrevala Foundation', contact: 'Call +91 9999 666 555', desc: 'Free 24/7 professional counseling helpline.' },
      { name: 'KIRAN Helpline', contact: 'Call 1800-599-0019', desc: 'Mental health rehabilitation helpline by Ministry of Social Justice.' }
    ],
    ca: [
      { name: '988 Suicide Crisis Helpline Canada', contact: 'Call or Text 988', desc: 'Toll-free, bilingual 24/7 suicide prevention service.' },
      { name: 'Kids Help Phone', contact: 'Text CONNECT to 686868', desc: '24/7 support for young people.' }
    ],
    au: [
      { name: 'Lifeline Australia', contact: 'Call 13 11 14', desc: '24-hour crisis support and suicide prevention.' },
      { name: 'Beyond Blue', contact: 'Call 1300 22 4636', desc: 'Support for anxiety, depression, and mental health.' }
    ]
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-fade-in">
      <div className="glass-panel w-full max-w-xl p-6 sm:p-8 rounded-3xl border border-rose-500/30 max-h-[90vh] overflow-y-auto space-y-6 text-left shadow-2xl">
        <div className="flex justify-between items-start">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-2xl bg-rose-500/20 text-rose-300">
              <i data-lucide="shield-alert" className="w-6 h-6"></i>
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">Need More Help?</h3>
              <p className="text-xs text-slate-300">You are not alone. Support is always available.</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1">✕</button>
        </div>

        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 text-xs text-slate-300 leading-relaxed space-y-1.5">
          <p className="font-semibold text-white">Wellness Companion Notice:</p>
          <p>
            <strong>Reset</strong> is an everyday emotional wellness tool and is <strong>not</strong> a medical diagnostic, therapeutic, or crisis treatment application. It does not diagnose or treat clinical conditions.
          </p>
          <p>
            If you are experiencing severe, overwhelming, or persistent distress, please reach out to a qualified healthcare provider or a trusted person.
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-rose-500/15 border border-rose-500/40 text-xs text-rose-200">
          <strong>Immediate Danger or Self-Harm:</strong> If you or someone you know is in immediate danger, please call your local emergency services (e.g., 911, 999, 112) or go to the nearest emergency room right away.
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
              Crisis & Support Hotlines
            </span>
            <select
              value={selectedCountry}
              onChange={(e) => setSelectedCountry(e.target.value)}
              className="px-3 py-1 rounded-xl bg-slate-900 border border-white/15 text-xs text-white"
            >
              <option value="us">🇺🇸 United States</option>
              <option value="uk">🇬🇧 United Kingdom</option>
              <option value="in">🇮🇳 India</option>
              <option value="ca">🇨🇦 Canada</option>
              <option value="au">🇦🇺 Australia</option>
            </select>
          </div>

          <div className="space-y-2.5">
            {lifelines[selectedCountry].map((line, idx) => (
              <div key={idx} className="p-3.5 rounded-2xl bg-white/5 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <div className="font-bold text-sm text-white">{line.name}</div>
                  <div className="text-xs text-slate-400">{line.desc}</div>
                </div>
                <span className="font-mono font-bold text-xs px-3 py-1.5 rounded-xl bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 self-start sm:self-center">
                  {line.contact}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="text-center text-xs text-slate-400">
          International directory available at{' '}
          <a
            href="https://findahelpline.com"
            target="_blank"
            rel="noopener noreferrer"
            className="text-indigo-300 underline"
          >
            findahelpline.com
          </a>
        </div>
      </div>
    </div>
  );
}

// ==========================================================================
// 13. SETTINGS & THEMES MODAL
// ==========================================================================

function SettingsModal({ user, onSignOut, googleClientId, setGoogleClientId, theme, setTheme, soundEnabled, toggleSound, soundVolume, setSoundVolume, ambientSound, setAmbientSound, onClearData, onExport, onImport, onClose }) {
  const fileInputRef = useRef(null);
  const [clientIdInput, setClientIdInput] = useState(googleClientId);

  const themes = [
    { id: 'dusk', label: 'Serene Dusk', desc: 'Calming twilight indigo', swatch: 'from-indigo-600 to-purple-600' },
    { id: 'sage', label: 'Calming Sage', desc: 'Herbal greens & earth tones', swatch: 'from-emerald-600 to-teal-600' },
    { id: 'midnight', label: 'Deep Midnight', desc: 'Dark obsidian & sky cyan', swatch: 'from-slate-900 to-cyan-800' },
    { id: 'sunrise', label: 'Warm Sunrise', desc: 'Soft terracotta & peach', swatch: 'from-rose-600 to-pink-600' }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-md animate-fade-in">
      <div className="glass-panel w-full max-w-lg p-6 rounded-3xl border border-white/15 max-h-[90vh] overflow-y-auto space-y-6 text-left shadow-2xl">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-bold text-white">Settings & Account</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white">✕</button>
        </div>

        {/* User Account Info if signed in */}
        {user && (
          <div className="p-4 rounded-2xl bg-indigo-500/10 border border-indigo-500/25 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <img src={user.picture} alt={user.name} className="w-10 h-10 rounded-full border border-indigo-400" />
              <div>
                <div className="font-bold text-sm text-white">{user.name}</div>
                <div className="text-xs text-indigo-300">{user.email}</div>
              </div>
            </div>
            <button
              onClick={() => {
                onSignOut();
                onClose();
              }}
              className="px-3 py-1.5 rounded-xl bg-rose-500/20 text-rose-300 hover:bg-rose-500/30 text-xs font-semibold"
            >
              Sign Out
            </button>
          </div>
        )}

        {/* Theme Chooser */}
        <div className="space-y-2.5">
          <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
            Color Theme
          </div>
          <div className="grid grid-cols-2 gap-2.5">
            {themes.map(th => (
              <button
                key={th.id}
                onClick={() => setTheme(th.id)}
                className={`p-3 rounded-2xl border text-left transition-all ${
                  theme === th.id
                    ? 'border-indigo-400 bg-indigo-500/20 font-semibold text-white'
                    : 'border-white/10 bg-white/5 text-slate-300 hover:bg-white/10'
                }`}
              >
                <div className={`w-full h-2 rounded-full bg-gradient-to-r ${th.swatch} mb-2`}></div>
                <div className="text-xs font-bold">{th.label}</div>
                <div className="text-[10px] text-slate-400">{th.desc}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Sound Controls */}
        <div className="space-y-3 border-t border-white/10 pt-4">
          <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
            Sound & Ambient Audio
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-200">Audio Feedback & Chimes</span>
            <button
              onClick={toggleSound}
              className={`px-3 py-1 rounded-xl text-xs font-semibold ${
                soundEnabled ? 'bg-indigo-600 text-white' : 'bg-white/10 text-slate-400'
              }`}
            >
              {soundEnabled ? 'Enabled' : 'Muted'}
            </button>
          </div>

          <div>
            <div className="flex justify-between text-xs text-slate-300 mb-1">
              <span>Volume</span>
              <span>{Math.round(soundVolume * 100)}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={soundVolume}
              onChange={(e) => setSoundVolume(parseFloat(e.target.value))}
              className="w-full accent-indigo-500"
            />
          </div>
        </div>

        {/* Data & Privacy */}
        <div className="space-y-3 border-t border-white/10 pt-4">
          <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
            Data & Privacy
          </div>
          <p className="text-xs text-slate-400">
            All reset entries are stored directly in your browser's LocalStorage. You can export a backup or clear all data.
          </p>

          <div className="flex flex-wrap gap-2 pt-1">
            <button
              onClick={onExport}
              className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs text-white font-medium"
            >
              Export Data (JSON)
            </button>
            <input
              type="file"
              ref={fileInputRef}
              onChange={onImport}
              accept=".json"
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current && fileInputRef.current.click()}
              className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs text-white font-medium"
            >
              Import Backup
            </button>
            <button
              onClick={onClearData}
              className="px-3 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-xs text-rose-300 font-medium"
            >
              Clear All Data
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ==========================================================================
// 14. FOOTER COMPONENT
// ==========================================================================

function FooterNav({ user, onOpenSafety, onOpenSettings, onViewDashboard, onGoToLogin }) {
  return (
    <footer className="relative z-10 border-t border-white/10 py-6 px-4 mt-12 bg-black/20 backdrop-blur-md">
      <div className="max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
        <div className="flex items-center space-x-2">
          <span className="font-bold text-slate-200">Reset</span>
          <span>•</span>
          <span>Instant Emotional Wellness</span>
        </div>

        <div className="flex items-center space-x-4">
          <button
            onClick={onOpenSafety}
            id="btn-safety-footer"
            className="text-indigo-300 hover:text-indigo-200 font-semibold underline decoration-dotted"
          >
            Need more help?
          </button>
          <span>•</span>
          <button onClick={onViewDashboard} className="hover:text-white">
            Dashboard
          </button>
          <span>•</span>
          {!user ? (
            <button onClick={onGoToLogin} className="hover:text-white">
              Google Login
            </button>
          ) : (
            <span className="text-emerald-400">● Signed in as {user.given_name || user.name.split(' ')[0]}</span>
          )}
          <span>•</span>
          <button onClick={onOpenSettings} className="hover:text-white">
            Settings
          </button>
        </div>

        <div className="text-[11px] text-slate-400 text-center sm:text-right">
          Non-clinical • 100% Private on-device
        </div>
      </div>
    </footer>
  );
}

// Render React App
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
